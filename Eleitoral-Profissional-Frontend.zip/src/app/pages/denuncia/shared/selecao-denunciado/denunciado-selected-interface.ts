export class DenunciadoSelectedInterface {
    uf?: any;
    chapa?: any;
    membro?: {};
    tipoDenuncia?: any;
}
