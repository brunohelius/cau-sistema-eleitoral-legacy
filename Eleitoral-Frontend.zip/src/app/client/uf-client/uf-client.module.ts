import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Modulo de integração do projeto frontend com os serviços backend.
 */
@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class UFClientModule { }