import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alerta-denuncia-sigilosa',
  templateUrl: './alerta-denuncia-sigilosa.component.html',
  styleUrls: ['./alerta-denuncia-sigilosa.component.scss']
})
export class AlertaDenunciaSigilosaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
